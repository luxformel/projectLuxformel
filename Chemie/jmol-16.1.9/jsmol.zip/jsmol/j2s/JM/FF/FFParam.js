Clazz.declarePackage ("JM.FF");
c$ = Clazz.decorateAsClass (function () {
this.iVal = null;
this.dVal = null;
this.sVal = null;
Clazz.instantialize (this, arguments);
}, JM.FF, "FFParam");
